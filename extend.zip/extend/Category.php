<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/9/11 0011
 * Time: 上午 10:28
 * v
 */
class Category
{

    /**
     * @desc
     * @params int $a 所有的分类
     * @params int $pid 父分类ID
     * @return String
     */
    public static function get_attr($a,$pid){
        $tree = array();                                //每次都声明一个新数组用来放子元素
        foreach($a as $v){
            if($v['pid'] == $pid){                      //匹配子记录
                $v['children'] = self::get_attr($a,$v['id']); //递归获取子记录
                if($v['children'] == null){
                    unset($v['children']);             //如果子元素为空则unset()进行删除，说明已经到该分支的最后一个元素了（可选）
                }
                $tree[] = $v;                           //将记录存入新数组
            }
        }
        return $tree;                                  //返回新数组
    }

    /**
     * @desc
     * @params int $a 所有的分类
     * @params int $pid 父分类ID
     * @params int $catSelectedId 设定选中的分类ID
     * @params int $curLevel 层数
     * @return String
     */
    public static function getOptionHtml($a,$pid,$catSelectedId=0,$curLevel=0){
        $html = '';
        foreach($a as $v){
            if($v['pid'] == $pid){
                $children = self::getOptionHtml($a,$v['id'],$catSelectedId,$curLevel+1);

                $nb = '';
                for($i=0; $i<$curLevel; $i++){
                    $nb.='&nbsp;&nbsp;';
                }

                if($catSelectedId == $v['id']){
                    $html.=('<option value='.$v['id'].' selected>'.$nb.$v['name'].'</option>'.$children);
                }else{
                    $html.=('<option value='.$v['id'].'>'.$nb.$v['name'].'</option>'.$children);
                }

            }
        }
        return $html;
    }

    private function catListSort($a,$pid,$curLevel=0){

    }

    /**
     * @desc 获取指定分类的所有子分类
     * @params int $a 所有的分类
     * @params int $pid 父分类ID
     * @return array
     */
    public static function getAllChildrenArr($allCatArr,$pid = 0){
        if($pid == 0){
            return $allCatArr;
        }
        $childrenArr = array();
        foreach($allCatArr as $item){
            if($item['pid'] == $pid){
                $children = self::getAllChildrenArr($allCatArr,$item['id']);
                $childrenArr[] = $item;
                $childrenArr = array_merge((array)$children,(array)$childrenArr);
            }
        }
        return $childrenArr;
    }

    /**
     * @desc 获取指定分类的所有子分类的id数组
     * @params int $allCatArr 所有的分类
     * @params int $pid 父分类ID
     * @return array
     */
    public static function getAllChildrenIdArr($allCatArr,$pid){
        $arr = array();
        foreach($allCatArr as $item){
            if($item['pid'] == $pid){
                $childrenIdArr = self::getAllChildrenIdArr($allCatArr,$item['id']);
                $arr[] = $item['id']; //到叶子节点才会执行这句
                $arr = array_merge($arr,$childrenIdArr);
            }
        }
        return $arr;
    }

    /**
     * @desc 获取指定分类的所有子分类的id字符串
     * @params int $allCatArr 所有的分类
     * @params int $pid 父分类ID
     * @return string
     */
    public static function getAllChildrenIdStr($allCatArr,$pid){
        $idArr = self::getAllChildrenIdArr($allCatArr,$pid);
        $idStr = '';
        foreach($idArr as $id){
            $idStr .= ($id.',');
        }
        return substr($idStr,0,-1);
    }

    /**
     * @desc 获取指定分类的所有子分类的id字符串,最后会多一个逗号
     * @params int $allCatArr 所有的分类
     * @params int $pid 父分类ID
     * @return string
     */
    public static function getAllChildrenIdStr2($allCatArr,$pid){
        $str = '';
        foreach($allCatArr as $item){
            if($item['pid'] == $pid){
                $childrenIdStr = self::getAllChildrenIdStr($allCatArr,$item['id']);
                $str .= ($item['id'].','.$childrenIdStr);
            }
        }
        return $str;
    }

    /**
     * @desc 获取指定分类的顶级分类id
     * @params int $cid 分类ID
     * @return string
     */
    public static function getTopCatId($allCatArr,$cid){
        $pid = Category::getParentId($allCatArr,$cid);
        if($pid == 0){
            return $cid;
        }else{
            return Category::getTopCatId($allCatArr,$pid);
        }
    }

    public function getParentId($allCatArr,$cid){
        foreach($allCatArr as $cat){
            if($cat['id'] == $cid){
                return $cat['pid'];
            }
        }
    }





}