<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/29 0029
 * Time: 下午 5:36
 */
class MobileLocation
{
    //聚合api 电话归属地
    protected $sendurl = "http://apis.juhe.cn/mobile/get";
    protected $key = "eb8e469e6284693826f1891dd6ba8139";

    //发送验证码
    //成功返回0,失败返回错误代码
    public function get($phone)
    {
        $MobileLocation = db('mobile_location');
        $mobileLocation = $MobileLocation->where(array('phone'=>$phone))->find();
        if(!$mobileLocation) {
            $sendurl = $this->sendurl . '?phone=' . $phone . '&key=' . $this->key;
            $rs = file_get_contents($sendurl);

            //echo $rs;
            $rsArr = json_decode($rs,true);
            if($rsArr['resultcode'] == '200' && $rsArr['error_code'] == 0){
                //写入数据
                $result = $rsArr['result'];
                $inData = array(
                    'phone'=>$phone,
                    'province'=>$result['province'],
                    'city'=>$result['city'],
                    'areacode'=>$result['areacode'],
                    'zip'=>$result['zip'],
                    'company'=>$result['company'],
                    'add_time'=>time()
                );
                $MobileLocation->insert($inData);
                return $result;
            }
            return false;
        }
        //var_dump($mobileLocation);
        return $mobileLocation;
    }
}